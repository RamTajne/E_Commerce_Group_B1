package com.productdetails;

import java.sql.*;
import java.util.ArrayList;

public class ProductDetails 
{
	PreparedStatement ps = null;
	Connection con = null;
	public void getProductDetails(int product_id, String name, int quantity, int price, String description)
	{
		try 
		{
			UserLogin userlogin = new UserLogin();
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/productdetails", "root", "root");
			ps = con.prepareStatement("select * from product");
			
			ArrayList<User> array = new ArrayList<User>();
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				User user = new User();
				user.setProduct_id(rs.getInt("product_id"));
				user.setName(rs.getString("name"));
				user.setQuantity(rs.getInt("quantity"));
				user.setPrice(rs.getInt("price"));
				user.setDescription(rs.getString("description"));
				array.add(user);
//				System.out.println(rs.getInt("product_id"));
//				System.out.println(rs.getString("name"));
//				System.out.println(rs.getInt("quantity"));
//				System.out.println(rs.getInt("price"));
//				System.out.println(rs.getString("description"));
			}
//			for(User u :array)
//			{
//				System.out.println("Product ID : "+u.getProduct_id() );
//				System.out.println("Product Name : " +u.getName());
//				System.out.println("Product Quantity : "+u.getQuantity());
//				System.out.println("Product Price : " +u.getPrice());
//				System.out.println("Product Description : " +u.getDescription());
//						
//			}
			User.displayFormat();  
	         for (User p : array)   
	         {  
	             p.display();  
	         }
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
