package com.productdetails;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Scanner;

public class ProductPurchase
{
	PreparedStatement ps = null;
	PreparedStatement ps1 = null;
	Connection con = null;
	public void getUserPurchaseDetails()
	{
		try
		{
			UserLogin userlogin = new UserLogin();
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/productdetails", "root", "root");
			Scanner scanner= new Scanner(System.in);
			System.out.println("Enter the product id : ");
			int product_id=scanner.nextInt();
			System.out.println("Enter the quantity : ");
			int quantity= scanner.nextInt();
			System.out.println("Enter the price : ");
			int price = scanner.nextInt();
			double totalprice = price * quantity;
			System.out.println("Total price of all products : " + totalprice);
			System.out.println("All products added sucessfully");
			ps= con.prepareStatement("insert into userpurchase values(?,?,?,?)");
			ps.setInt(1,product_id);
			ps.setInt(2, quantity);
			ps.setInt(3, price);
			ps.setDouble(4, totalprice);
			
			ps1= con.prepareStatement("select * from userpurchase");
			
			ArrayList<User> array = new ArrayList<User>();
			
			int i=ps.executeUpdate();
			//System.out.println(i);
			ResultSet rs=ps1.executeQuery();
			
			while(rs.next())
			{
				User user = new User();
				user.setProduct_id(rs.getInt("product_id"));
				user.setQuantity(rs.getInt("quantity"));
				user.setPrice(rs.getInt("price"));
				user.setTotalprice(rs.getDouble("totalprice"));
				array.add(user);
			
			}

			User.displayFormat1();  
	         for (User p : array)   
	         {  
	             p.display1();  
	         }
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
	
}
