package com.productdetails;

import java.sql.*;
import java.util.Scanner;
public class UserLoginDetails extends ProductDetails
{
	PreparedStatement ps = null;
	Connection con = null;
	public void getUserLoginDetails()
	{
		try 
		{
			UserLogin userlogin = new UserLogin();
			con = userlogin.getConnection();
			ps = con.prepareStatement(" insert into login values(?,?)");
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter User Name : ");
			String username=sc.nextLine();
			System.out.println("Enter Password : ");
			String password = sc.nextLine();
			ps.setString(1, username);
			ps.setString(2, password);
			int i = ps.executeUpdate();//remove later
			System.out.println("************************* You have Login Successfully.*************************"  );
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
