package com.productdetails;

public class User 
{
	private int product_id;
	private String name;
	private int quantity;
	private int price;
	private String description;
	private double totalprice;
	
	
	//getter and setter
	public int getProduct_id() {
		return product_id;
	}
	public void setProduct_id(int product_id) {
		this.product_id = product_id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public double getTotalprice() {
		return totalprice;
	}
	public void setTotalprice(double totalprice) {
		this.totalprice = totalprice;
	}
	//creating constructor 
	public User(int product_id, String name, int quantity, int price, String description) {
		super();
		this.product_id = product_id;
		this.name = name;
		this.quantity = quantity;
		this.price = price;
		this.description = description;
	}
	public User() 
	{
		
	}
	
	public static void displayFormat()   
    {  
        System.out.print("-----------------------------------------------------------------------------------------------------------------------------------");  
        System.out.print("\nProduct ID \t\tname\t\t\tquantity\t\tprice \t\t\t\tdescription\n");  
        System.out.print("-----------------------------------------------------------------------------------------------------------------------------------\n");  
    }
	public void display() 
	{
        System.out.format("   %-9s "
        		+ "            %-9s   "
        		+ "   %9s     "
        		+ "          %9s      "
        		+ "                 %9s\n" 
        		,product_id, name, quantity, price, description );

	}
	public static void displayFormat1()   
    {  //userpurchase format
        System.out.print("-----------------------------------------------------------------------------------------------------------------------------------");  
        System.out.print("\nProduct ID \t\tquantity\t\t\tprice\t\ttotalprice\n");  
        System.out.print("-----------------------------------------------------------------------------------------------------------------------------------\n");  
    }
	public void display1()
	{//userpurchase display
        System.out.format("   %-9s "
        		+ "            %-9s   "
        		+ "   %9s     "
        		+ "          %9s\n"
        		
        		,product_id, quantity , price, totalprice );

	}
	
	
	
	
	
}
