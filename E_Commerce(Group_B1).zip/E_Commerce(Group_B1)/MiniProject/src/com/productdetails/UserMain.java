package com.productdetails;

import java.util.Scanner;

public class UserMain 
{
	public static void main(String[] args)
	{
		UserLoginDetails userLoginDetails = new UserLoginDetails();
		System.out.println("-----------------------------------WELCOME TO E-CART---------------------------------");
		System.out.println("   ");
		userLoginDetails.getUserLoginDetails();
		//ProductDetails productDetails = new ProductDetails();
		int product_id=0;
		String name=null;
		int quantity=0;
		int price=0;
		String description=null;
		System.out.println();
		System.out.println("-----------------------------------Menu Card-----------------------------------");
		System.out.println("   ");
		userLoginDetails.getProductDetails(product_id, name, quantity, price, description);
		System.out.println();
		System.out.println("-----------------------------------Add Your Products To Cart-----------------------------------");
		System.out.println("   ");
		ProductPurchase productPurchase= new ProductPurchase();
		productPurchase.getUserPurchaseDetails();
			
	}
}
